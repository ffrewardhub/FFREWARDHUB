/* Poora JavaScript code jo maine pichle response mein diya tha, yahan paste karein */
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";
import { getFirestore, doc, setDoc, onSnapshot, updateDoc, increment, collection, addDoc } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";
const firebaseConfig = {
    apiKey: "AIzaSyDBcPggJxq4yrPLoZwVwFNoA341b2BISkQ",
    authDomain: "reward-hub-4d851.firebaseapp.com",
    projectId: "reward-hub-4d851",
    storageBucket: "reward-hub-4d851.firebasestorage.app",
    messagingSenderId: "961561066999",
    appId: "1:961561066999:web:a5964e9a9ea04e46bbc2f2",
    measurementId: "G-BL5887T9J3"
};
const app = initializeApp(firebaseConfig);
/* Baqi tamam JavaScript... */